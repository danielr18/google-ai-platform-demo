# NLP
NLP model for text classification.

Here is the live demo:
https://danielecordano.github.io/NLP/

Thanks to Keith Galli for his dataset:
https://github.com/KeithGalli/sklearn/blob/master/data/sentiment/Books_small_10000.json

Thanks to Jianmo Ni for his datasets:
https://nijianmo.github.io/amazon/index.html

Thanks to Laurence Moroney for his "Tensorflow in practice" specialization on Coursera.
The notebook is inspired by:
https://github.com/lmoroney/dlaicourse/blob/master/TensorFlow%20In%20Practice/Course%203%20-%20NLP/NLP%20Course%20-%20Week%203%20Exercise%20Answer.ipynb
